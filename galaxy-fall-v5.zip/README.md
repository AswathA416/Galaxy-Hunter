# GALAXY FALL (v5)

One-file, third-person galaxy battle royale. Open `index.html` to play. No libraries, no build, no accounts. Progress saves in your browser. Cost: $0.

## New in v5
- Buildings with window frames and glass, sills, door frames, chimneys and roof trim.
- Treasure chests across the map. Stand next to one and press E to open it. Gold chests give better loot.
- Change your username from the Play tab ("Save name"). The loading screen shows the new name.

## Controls
WASD move · Space jump / open glider · Shift sprint · mouse look (click to capture, Esc to release) · left click fire · E open chest · 1 pickaxe, 2–4 weapons, mouse wheel cycles · Q build mode (1 wall, 2 floor, 3 ramp).

## Publish on GitHub Pages (free)
1. Create a public repo, e.g. `galaxy-fall`, on github.com.
2. Add file → Upload files → `index.html` → Commit.
3. Settings → Pages → Deploy from a branch → `main` / root → Save.
4. Play at `https://<your-username>.github.io/galaxy-fall/` after about a minute.

## Limits
- Building is wall, floor and ramp only. Fortnite-style roofs, stairs and edit mode are not in yet.
- Buildings are procedural boxes, not modeled meshes. They look more like buildings than before, but not like photoreal architecture.
- Bots are AI, not other players. Online play needs a server, which GitHub Pages can't run.
